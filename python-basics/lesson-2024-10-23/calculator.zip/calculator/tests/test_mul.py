import unittest


class TestMultiplicationTestCase(unittest.TestCase):
    def test_mul_two_numbers(self):
        # Arrange
        x = 4
        y = 3
        expected_result = 12

        # Act
        result = multiply(x, y)

        # Assert
        # Later, we will use unittest methods to assert
        assert (
            result == expected_result
        ), f"Expected {expected_result}, but got {result}"


if __name__ == "__main__":
    unittest.main()
